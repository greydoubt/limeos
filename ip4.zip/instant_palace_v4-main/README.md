# instant_palace_v4




Installation:
-------------

Put all the files and directory in your root web directory

Replace this 3 files: ip_select.html , ip_ms.html and ip_sun.htmt 

Edit this files: ip_sun.html :

<PARAM name=palaceport value=9998>
<PARAM name=tunnelport value=80>
<PARAM name=palacehost value=your-server-address.com>
<PARAM name=picfolder value=/your-media-directory/>
<PARAM name=soundfolder value=/your-media-directory/>

And edit this file: ip_ms.html :

<PARAM name=palaceport value=9998>
<PARAM name=tunnelport value=80>
<PARAM name=palacehost value=your-server-address.com>
<PARAM name=picfolder value=/your-media-directory/>
<PARAM name=soundfolder value=/your-media-directory/>

----

After:

Conect to you server with God rank and type:
'guest on

And:
'entrypage http://your-server-address.com/ip_select.html

And:
`avatarurl http://your-server-address.com/avatars/

And After:
`avatarurl on

----

And conect to this file:
http://your-server-address.com/ip_select.html

